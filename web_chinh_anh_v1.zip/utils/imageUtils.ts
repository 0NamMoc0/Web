
import { AnalysisResult } from '../types';

// Function to calculate Laplacian variance for sharpness estimation
function calculateLaplacianVariance(ctx: CanvasRenderingContext2D, width: number, height: number): number {
    const imageData = ctx.getImageData(0, 0, width, height);
    const data = imageData.data;
    let laplacianSum = 0;
    let pixelCount = 0;

    // Laplacian kernel
    const kernel = [
        [0, 1, 0],
        [1, -4, 1],
        [0, 1, 0]
    ];

    for (let y = 1; y < height - 1; y++) {
        for (let x = 1; x < width - 1; x++) {
            let sumR = 0, sumG = 0, sumB = 0;
            for (let ky = -1; ky <= 1; ky++) {
                for (let kx = -1; kx <= 1; kx++) {
                    const px = x + kx;
                    const py = y + ky;
                    const index = (py * width + px) * 4;
                    const weight = kernel[ky + 1][kx + 1];
                    sumR += data[index] * weight;
                    sumG += data[index + 1] * weight;
                    sumB += data[index + 2] * weight;
                }
            }
            // Use luminance for sharpness calculation
            const luminance = (sumR + sumG + sumB) / 3;
            laplacianSum += luminance * luminance;
            pixelCount++;
        }
    }

    return pixelCount > 0 ? laplacianSum / pixelCount : 0;
}


export const getOfflineAnalysis = (dataUrl: string): Promise<AnalysisResult> => {
    return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext('2d', { willReadFrequently: true });
            if (!ctx) {
                // Fallback result
                resolve({
                    is_offline: true,
                    overall_quality: 'fair',
                    sharpness_change: '=',
                    noise_reduction: false,
                    recommended_action: ['Không thể phân tích'],
                    confidence_score: 0,
                });
                return;
            }

            ctx.drawImage(img, 0, 0);
            
            const variance = calculateLaplacianVariance(ctx, img.width, img.height);
            
            let quality: 'excellent' | 'good' | 'fair' | 'poor' = 'fair';
            if (variance > 100) quality = 'excellent';
            else if (variance > 50) quality = 'good';
            else if (variance < 10) quality = 'poor';

            // Assume DPI is provided elsewhere, for now, we just check dimensions
            const ppi = Math.sqrt(img.width ** 2 + img.height ** 2) / 1; // Simplified PPI check
            const ppi_warning = ppi < 200; // Assuming a simple check, this is not accurate without physical size

            const result: AnalysisResult = {
                is_offline: true,
                overall_quality: quality,
                sharpness_change: '=',
                noise_reduction: false,
                recommended_action: ['Kiểm tra thủ công'],
                confidence_score: 0.8, // Static confidence for offline mode
                variance_laplacian: variance,
                ppi_warning: ppi_warning,
            };

            resolve(result);
        };
        img.src = dataUrl;
    });
};
