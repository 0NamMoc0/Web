
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { ImageState, AI_Mode, ApiStatus, StoredApiKey } from './types';
import { TEXTS } from './constants';
import ImageUploader from './components/ImageUploader';
import ApiKeyModal from './components/ApiKeyModal';
import { analyzeAndEnhanceImage, testGeminiConnection } from './services/geminiService';
import { getOfflineAnalysis } from './utils/imageUtils';

const App: React.FC = () => {
    const [image1, setImage1] = useState<ImageState | null>(null);
    const [image2, setImage2] = useState<ImageState | null>(null);
    const [aiMode, setAiMode] = useState<AI_Mode>(AI_Mode.Standard);
    
    const [apiKeys, setApiKeys] = useState<StoredApiKey[]>(() => {
        try {
            const stored = localStorage.getItem('gemini_api_key_store');
            return stored ? JSON.parse(stored) : [];
        } catch {
            return [];
        }
    });
    const [activeApiKeyId, setActiveApiKeyId] = useState<string | null>(() => localStorage.getItem('gemini_active_api_key_id'));
    
    const [isApiKeyModalOpen, setApiKeyModalOpen] = useState(false);
    const [apiStatus, setApiStatus] = useState<ApiStatus>('UNCHECKED');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const activeApiKey = useMemo(() => apiKeys.find(k => k.id === activeApiKeyId), [apiKeys, activeApiKeyId]);

    const isAiDisabled = useMemo(() => !activeApiKey, [activeApiKey]);
    
    useEffect(() => {
      setApiStatus(activeApiKey ? 'UNCHECKED' : 'NO_KEY');
    }, [activeApiKey]);

    const handleSelectApiKey = (id: string) => {
        setActiveApiKeyId(id);
        localStorage.setItem('gemini_active_api_key_id', id);
        setApiStatus('UNCHECKED');
    };

    const handleSaveApiKey = (name: string, key: string) => {
        const newKey: StoredApiKey = { id: Date.now().toString(), name, key };
        const updatedKeys = [...apiKeys, newKey];
        setApiKeys(updatedKeys);
        localStorage.setItem('gemini_api_key_store', JSON.stringify(updatedKeys));
        if (!activeApiKeyId) {
            handleSelectApiKey(newKey.id);
        }
    };

    const handleDeleteApiKey = (id: string) => {
        const updatedKeys = apiKeys.filter(k => k.id !== id);
        setApiKeys(updatedKeys);
        localStorage.setItem('gemini_api_key_store', JSON.stringify(updatedKeys));
        if (activeApiKeyId === id) {
            const newActiveId = updatedKeys.length > 0 ? updatedKeys[0].id : null;
            setActiveApiKeyId(newActiveId);
            if (newActiveId) {
              localStorage.setItem('gemini_active_api_key_id', newActiveId);
            } else {
              localStorage.removeItem('gemini_active_api_key_id');
            }
        }
    };

    const checkApiKeyAndModel = useCallback(async () => {
        if (!activeApiKey) {
            setApiStatus('NO_KEY');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            const model = aiMode === AI_Mode.Standard ? 'gemini-2.5-pro' : 'gemini-2.5-flash-image';
            const success = await testGeminiConnection(activeApiKey.key, model);
            if (success) {
                setApiStatus('OK');
                alert(TEXTS.API_MODEL_SUCCESS_MSG);
            } else {
                setApiStatus('ERROR');
                 alert(TEXTS.API_MODEL_FAIL_MSG);
            }
        } catch (e: any) {
            setApiStatus('ERROR');
            setError(e.message);
            alert(`${TEXTS.API_CONNECT_FAIL_MSG}: ${e.message}`);
        } finally {
            setIsLoading(false);
        }
    }, [activeApiKey, aiMode]);

    const handleSync = () => {
        if (!image1 || !image2) {
            alert(TEXTS.SYNC_INSTRUCTION);
            return;
        }

        const targetWidthPx = image1.width;
        const targetHeightPx = image1.height;
        const targetDpi = image1.dpi;

        const originalWidthPx = image2.width;
        const originalHeightPx = image2.height;
        const originalAspectRatio = originalWidthPx / originalHeightPx;
        
        const targetAspectRatio = targetWidthPx / targetHeightPx;
        
        let newWidthPx, newHeightPx;

        if (originalAspectRatio > targetAspectRatio) {
            newWidthPx = targetWidthPx;
            newHeightPx = newWidthPx / originalAspectRatio;
        } else {
            newHeightPx = targetHeightPx;
            newWidthPx = newHeightPx * originalAspectRatio;
        }

        newWidthPx = Math.round(newWidthPx);
        newHeightPx = Math.round(newHeightPx);

        const imgToResize = new Image();
        imgToResize.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = newWidthPx;
            canvas.height = newHeightPx;
            const ctx = canvas.getContext('2d');

            if (ctx) {
                ctx.drawImage(imgToResize, 0, 0, newWidthPx, newHeightPx);
                const dataUrl = canvas.toDataURL(image2.file.type);
                
                setImage2(prev => {
                    if (!prev) return null;
                    return {
                        ...prev,
                        dataUrl: dataUrl,
                        width: newWidthPx,
                        height: newHeightPx,
                        dpi: targetDpi,
                        isSynced: true,
                        enhancedDataUrl: null,
                        analysisResult: null,
                    };
                });
            }
        };
        imgToResize.src = image2.dataUrl;
    };
    
    const handleAnalysis = useCallback(async (target: 'image1' | 'image2' | 'both') => {
        if (isAiDisabled && aiMode !== AI_Mode.Offline) {
            alert(TEXTS.API_KEY_REQUIRED_MSG);
            return;
        }

        setIsLoading(true);
        setError(null);

        const processImage = async (imgState: ImageState, setState: React.Dispatch<React.SetStateAction<ImageState | null>>) => {
            if (aiMode === AI_Mode.Offline) {
                const offlineResult = await getOfflineAnalysis(imgState.dataUrl);
                setState(prev => prev ? { ...prev, analysisResult: offlineResult } : null);
                return;
            }

            if (!activeApiKey) {
                setError(TEXTS.API_KEY_REQUIRED_MSG);
                return;
            }

            try {
                const model = aiMode === AI_Mode.Standard ? 'gemini-2.5-pro' : 'gemini-2.5-flash-image';
                const result = await analyzeAndEnhanceImage(imgState, model, activeApiKey.key);
                setState(prev => prev ? { ...prev, analysisResult: result, enhancedDataUrl: `data:image/jpeg;base64,${result.enhanced_image}` } : null);
            } catch (e: any) {
                setError(`${TEXTS.ANALYSIS_ERROR}: ${e.message}`);
            }
        };

        if ((target === 'image1' || target === 'both') && image1) {
            await processImage(image1, setImage1);
        }
        if ((target === 'image2' || target === 'both') && image2) {
            await processImage(image2, setImage2);
        }

        setIsLoading(false);
    }, [aiMode, activeApiKey, image1, image2, isAiDisabled]);

    const getApiStatusBadge = () => {
        switch (apiStatus) {
            case 'OK': return <span className="bg-green-500 text-white text-xs font-medium me-2 px-2.5 py-0.5 rounded-full">{TEXTS.STATUS_VALID}</span>;
            case 'ERROR': return <span className="bg-red-500 text-white text-xs font-medium me-2 px-2.5 py-0.5 rounded-full">{TEXTS.STATUS_ERROR}</span>;
            case 'NO_KEY': return <span className="bg-gray-500 text-white text-xs font-medium me-2 px-2.5 py-0.5 rounded-full">{TEXTS.STATUS_NO_KEY}</span>;
            default: return <span className="bg-yellow-500 text-white text-xs font-medium me-2 px-2.5 py-0.5 rounded-full">{TEXTS.STATUS_UNCHECKED}</span>;
        }
    };
    
    const modelName = aiMode === AI_Mode.Standard ? "Gemini 2.5 Pro" : aiMode === AI_Mode.Creative ? "Banana Mode 🍌" : TEXTS.MODE_OFFLINE_LABEL;

    return (
        <div className="min-h-screen bg-gray-900 text-gray-100 p-4 sm:p-6 lg:p-8 font-sans">
            {isLoading && (
                <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
                    <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
                </div>
            )}
            <header className="text-center mb-8">
                <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">{TEXTS.APP_TITLE}</h1>
                <p className="text-gray-400 mt-2">{TEXTS.APP_SUBTITLE}</p>
            </header>

            <main>
                <div className="max-w-7xl mx-auto bg-gray-800/50 backdrop-blur-sm rounded-2xl shadow-2xl p-6 mb-8 border border-gray-700">
                    <h2 className="text-2xl font-semibold mb-4 text-gray-200 border-b-2 border-blue-500 pb-2">{TEXTS.CONFIG_TITLE}</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                        <div className="flex flex-col gap-2">
                            <label htmlFor="ai-mode" className="font-medium text-gray-300">{TEXTS.AI_MODE_LABEL}</label>
                            <select id="ai-mode" value={aiMode} onChange={e => setAiMode(e.target.value as AI_Mode)} className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 focus:ring-blue-500 focus:border-blue-500">
                                <option value={AI_Mode.Standard}>{TEXTS.MODE_STANDARD}</option>
                                <option value={AI_Mode.Creative}>{TEXTS.MODE_CREATIVE}</option>
                                <option value={AI_Mode.Offline}>{TEXTS.MODE_OFFLINE}</option>
                            </select>
                            <p className="text-sm text-gray-400 mt-1">{TEXTS.CURRENT_MODEL_LABEL}: {modelName}</p>
                        </div>
                        <div className="flex flex-col gap-2">
                             <p className="font-medium text-gray-300">{TEXTS.API_KEY_STATUS_LABEL}</p>
                            <div className="flex items-center gap-2">
                               {getApiStatusBadge()}
                               <span className="text-sm text-gray-400 truncate">{TEXTS.SELECTED_KEY_LABEL}: {activeApiKey ? activeApiKey.name : 'Chưa chọn'}</span>
                            </div>
                            <div className="flex flex-wrap gap-2 mt-2">
                                <button onClick={() => setApiKeyModalOpen(true)} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors text-sm">{TEXTS.ADD_API_KEY_BTN}</button>
                                <button onClick={checkApiKeyAndModel} disabled={isLoading || !activeApiKey} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition-colors text-sm disabled:bg-gray-500 disabled:cursor-not-allowed">{TEXTS.CHECK_API_MODEL_BTN}</button>
                            </div>
                        </div>
                        <div className="flex flex-col gap-2">
                            <p className="font-medium text-gray-300">{TEXTS.SYNC_TITLE}</p>
                            <button onClick={handleSync} disabled={!image1 || !image2} className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed">{TEXTS.SYNC_SIZE_BTN}</button>
                            <p className="text-sm text-gray-400 mt-1">{TEXTS.SYNC_DESC}</p>
                        </div>
                    </div>
                     {error && <div className="mt-4 p-3 bg-red-900/50 border border-red-700 text-red-300 rounded-lg">{error}</div>}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <ImageUploader id="image1" title={TEXTS.IMAGE_1_TITLE} imageState={image1} setImageState={setImage1} onAnalyze={() => handleAnalysis('image1')} isAiDisabled={isAiDisabled && aiMode !== AI_Mode.Offline} aiMode={aiMode} uploadButtonText={TEXTS.UPLOAD_BTN_1} />
                    <ImageUploader id="image2" title={TEXTS.IMAGE_2_TITLE} imageState={image2} setImageState={setImage2} onAnalyze={() => handleAnalysis('image2')} isAiDisabled={isAiDisabled && aiMode !== AI_Mode.Offline} aiMode={aiMode} uploadButtonText={TEXTS.UPLOAD_BTN_2}/>
                </div>
                <div className="text-center mt-8">
                    <button onClick={() => handleAnalysis('both')} disabled={!image1 || !image2 || (isAiDisabled && aiMode !== AI_Mode.Offline)} className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white font-bold py-3 px-8 rounded-full transition-all shadow-lg text-lg disabled:from-gray-500 disabled:to-gray-600 disabled:cursor-not-allowed">
                        {TEXTS.ANALYZE_BOTH_BTN}
                    </button>
                </div>
            </main>
            {isApiKeyModalOpen && (
                <ApiKeyModal
                    onClose={() => setApiKeyModalOpen(false)}
                    onSave={handleSaveApiKey}
                    onDelete={handleDeleteApiKey}
                    onSelect={handleSelectApiKey}
                    apiKeys={apiKeys}
                    activeApiKeyId={activeApiKeyId}
                />
            )}
        </div>
    );
};

export default App;
