
export interface ImageState {
    file: File;
    dataUrl: string;
    width: number;
    height: number;
    dpi: number;
    isSynced?: boolean;
    enhancedDataUrl?: string | null;
    analysisResult?: AnalysisResult | null;
}

export interface AnalysisResult {
    overall_quality: 'excellent' | 'good' | 'fair' | 'poor' | string;
    sharpness_change: '+' | '=' | '-';
    noise_reduction: boolean;
    recommended_action: string[];
    confidence_score: number;
    enhanced_image?: string; // base64
    // Offline fields
    variance_laplacian?: number;
    ppi_warning?: boolean;
    is_offline?: boolean;
}

export enum AI_Mode {
    Standard = 'standard',
    Creative = 'creative',
    Offline = 'offline',
}

export type ApiStatus = 'UNCHECKED' | 'OK' | 'ERROR' | 'NO_KEY';

export interface VietnameseTexts {
    [key: string]: string;
}

export interface StoredApiKey {
  id: string;
  name: string;
  key: string;
}
