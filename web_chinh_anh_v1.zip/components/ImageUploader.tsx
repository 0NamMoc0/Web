import React from 'react';
import { ImageState, AI_Mode } from '../types';
import { TEXTS, DEFAULT_DPI } from '../constants';
import ImageCompareSlider from './ImageCompareSlider';
import saveAs from 'file-saver';

interface ImageUploaderProps {
    id: string;
    title: string;
    imageState: ImageState | null;
    setImageState: React.Dispatch<React.SetStateAction<ImageState | null>>;
    onAnalyze: () => void;
    isAiDisabled: boolean;
    aiMode: AI_Mode;
    uploadButtonText: string;
}

const QualityBadge: React.FC<{ quality: string }> = ({ quality }) => {
    const qualityMap: { [key: string]: { text: string; color: string } } = {
        excellent: { text: TEXTS.QUALITY_EXCELLENT, color: 'bg-green-500' },
        good: { text: TEXTS.QUALITY_GOOD, color: 'bg-blue-500' },
        fair: { text: TEXTS.QUALITY_FAIR, color: 'bg-yellow-500' },
        poor: { text: TEXTS.QUALITY_POOR, color: 'bg-red-500' },
    };
    const { text, color } = qualityMap[quality] || { text: quality, color: 'bg-gray-500' };
    return <span className={`text-white text-xs font-semibold px-2.5 py-1 rounded-full ${color}`}>{text}</span>;
};


const ImageUploader: React.FC<ImageUploaderProps> = ({ id, title, imageState, setImageState, onAnalyze, isAiDisabled, aiMode, uploadButtonText }) => {
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                const img = new Image();
                img.onload = () => {
                    setImageState({
                        file,
                        dataUrl: event.target?.result as string,
                        width: img.width,
                        height: img.height,
                        dpi: DEFAULT_DPI,
                    });
                };
                img.src = event.target?.result as string;
            };
            reader.readAsDataURL(file);
        }
    };

    const handleInputChange = (field: 'width' | 'height' | 'dpi', value: string) => {
        const numValue = parseInt(value, 10);
        if (!isNaN(numValue) && imageState) {
            setImageState({ ...imageState, [field]: numValue });
        }
    };

    const handleDownload = () => {
        if (!imageState) return;
        const urlToDownload = imageState.enhancedDataUrl || imageState.dataUrl;
        const modelName = aiMode === AI_Mode.Standard ? 'gemini-2.5-pro' : aiMode === AI_Mode.Creative ? 'banana-mode' : 'offline';
        const fileName = `${imageState.file.name.split('.')[0]}-${modelName}-${imageState.width}px-${imageState.height}px-${imageState.dpi}dpi.jpg`;
        saveAs(urlToDownload, fileName);
    };

    const copyJson = () => {
        if (imageState?.analysisResult) {
            navigator.clipboard.writeText(JSON.stringify(imageState.analysisResult, null, 2));
            alert('Đã sao chép JSON vào clipboard!');
        }
    };
    
    const saveReport = () => {
         if (!imageState?.analysisResult) return;
        const modelName = aiMode === AI_Mode.Standard ? 'gemini-2.5-pro' : aiMode === AI_Mode.Creative ? 'banana-mode' : 'offline';
        const fileName = `${imageState.file.name.split('.')[0]}-${modelName}-report.json`;
        const blob = new Blob([JSON.stringify(imageState.analysisResult, null, 2)], { type: 'application/json' });
        saveAs(blob, fileName);
    };

    const downloadButtonTextContent = imageState?.enhancedDataUrl ? TEXTS.DOWNLOAD_ENHANCED_BTN : TEXTS.DOWNLOAD_BTN;

    return (
        <div className="bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-700 h-full flex flex-col">
            <h3 className="text-xl font-bold text-center mb-4 text-gray-200">{title}</h3>
            <div className="flex-grow flex items-center justify-center bg-gray-900/50 rounded-lg min-h-[300px] mb-4 relative overflow-hidden">
                {imageState ? (
                    (imageState.enhancedDataUrl && imageState.analysisResult) ? (
                        <div className="w-full h-full relative">
                             <ImageCompareSlider
                                before={imageState.dataUrl}
                                after={imageState.enhancedDataUrl}
                            />
                            {aiMode === AI_Mode.Creative && (
                                <div className="absolute bottom-2 right-2 bg-black bg-opacity-60 text-white text-xs px-2 py-1 rounded">
                                    {TEXTS.BANANA_MODE_WATERMARK}
                                </div>
                            )}
                        </div>
                    ) : (
                        <img src={imageState.dataUrl} alt="Preview" className="max-w-full max-h-full object-contain rounded-lg" />
                    )
                ) : (
                    <div className="text-center text-gray-500">
                        <p>{TEXTS.UPLOAD_BTN}</p>
                    </div>
                )}
            </div>

            <div className="mb-4">
                <label htmlFor={`file-upload-${id}`} className="w-full text-center cursor-pointer bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors block">
                    {imageState ? TEXTS.CHANGE_BTN : uploadButtonText}
                </label>
                <input id={`file-upload-${id}`} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
            </div>

            {imageState && (
                <>
                    <div className="grid grid-cols-3 gap-4 mb-4">
                        <div>
                            <label className="text-sm font-medium text-gray-400">{TEXTS.WIDTH_LABEL}</label>
                            <input type="number" value={imageState.width} onChange={e => handleInputChange('width', e.target.value)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2 text-white" />
                        </div>
                        <div>
                            <label className="text-sm font-medium text-gray-400">{TEXTS.HEIGHT_LABEL}</label>
                            <input type="number" value={imageState.height} onChange={e => handleInputChange('height', e.target.value)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2 text-white" />
                        </div>
                        <div>
                            <label className="text-sm font-medium text-gray-400">{TEXTS.DPI_LABEL}</label>
                            <input type="number" value={imageState.dpi} onChange={e => handleInputChange('dpi', e.target.value)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2 text-white" />
                        </div>
                    </div>
                    
                    <button onClick={onAnalyze} disabled={isAiDisabled} className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition-colors mb-4 disabled:bg-gray-500 disabled:cursor-not-allowed">
                        {TEXTS.ANALYZE_BTN}
                    </button>

                    <div className="flex flex-wrap gap-2 mb-4">
                        <button onClick={handleDownload} className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-3 rounded-lg text-xs">{downloadButtonTextContent}</button>
                        <button onClick={copyJson} disabled={!imageState.analysisResult} className="flex-1 bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-3 rounded-lg text-xs disabled:bg-gray-500 disabled:cursor-not-allowed">{TEXTS.COPY_JSON_BTN}</button>
                        <button onClick={saveReport} disabled={!imageState.analysisResult} className="flex-1 bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-3 rounded-lg text-xs disabled:bg-gray-500 disabled:cursor-not-allowed">{TEXTS.SAVE_REPORT_BTN}</button>
                    </div>

                    {imageState.analysisResult && (
                        <div className="bg-gray-900/50 p-4 rounded-lg">
                            <h4 className="font-bold mb-2">{TEXTS.ANALYSIS_RESULTS_TITLE}
                                {imageState.analysisResult.is_offline && <span className="text-sm font-normal text-yellow-400 ml-2">({TEXTS.OFFLINE_ANALYSIS_NOTE})</span>}
                            </h4>
                            <div className="space-y-2 text-sm">
                                <div className="flex justify-between items-center"><span>{TEXTS.QUALITY_LABEL}:</span> <QualityBadge quality={imageState.analysisResult.overall_quality} /></div>
                                {imageState.analysisResult.is_offline ? (
                                    <>
                                     <div className="flex justify-between items-center"><span>{TEXTS.LAPLACIAN_LABEL}:</span> <span>{imageState.analysisResult.variance_laplacian?.toFixed(2)}</span></div>
                                     {imageState.analysisResult.ppi_warning && <div className="flex justify-between items-center text-yellow-400"><span>{TEXTS.PPI_WARNING_LABEL}:</span> <span>{TEXTS.PPI_LOW_MSG}</span></div>}
                                    </>
                                ) : (
                                    <>
                                        <div className="flex justify-between items-center"><span>{TEXTS.SHARPNESS_LABEL}:</span> <span>{imageState.analysisResult.sharpness_change === '+' ? TEXTS.SHARPNESS_INCREASE : imageState.analysisResult.sharpness_change === '=' ? TEXTS.SHARPNESS_SAME : TEXTS.SHARPNESS_DECREASE}</span></div>
                                        <div className="flex justify-between items-center"><span>{TEXTS.NOISE_LABEL}:</span> <span>{imageState.analysisResult.noise_reduction ? TEXTS.NOISE_REDUCED : TEXTS.NOISE_NOT_REDUCED}</span></div>
                                        <div className="flex justify-between items-center"><span>{TEXTS.RECOMMENDATIONS_LABEL}:</span> <span>{imageState.analysisResult.recommended_action.join(', ')}</span></div>
                                        <div className="flex justify-between items-center"><span>{TEXTS.CONFIDENCE_LABEL}:</span> <span>{(imageState.analysisResult.confidence_score * 100).toFixed(0)}%</span></div>
                                    </>
                                )}
                            </div>
                        </div>
                    )}
                </>
            )}
        </div>
    );
};

export default ImageUploader;