
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { ImageState, AnalysisResult } from "../types";

function dataUrlToBase64(dataUrl: string): string {
    return dataUrl.split(',')[1];
}

export async function testGeminiConnection(apiKey: string, model: string): Promise<boolean> {
    try {
        const ai = new GoogleGenAI({ apiKey });
        // The creative model doesn't support simple text prompts, so for the check,
        // we'll default to a model that does, ensuring the API key itself is tested correctly.
        const testModel = model === 'gemini-2.5-flash-image' ? 'gemini-2.5-pro' : model;
        const response = await ai.models.generateContent({
            model: testModel,
            contents: 'hello',
        });
        return !!response.text;
    } catch (error) {
        console.error("Lỗi kiểm tra kết nối Gemini:", error);
        throw error;
    }
}

export async function analyzeAndEnhanceImage(imageState: ImageState, model: string, apiKey: string): Promise<AnalysisResult> {
    const ai = new GoogleGenAI({ apiKey });

    const base64Image = dataUrlToBase64(imageState.dataUrl);
    
    // Handle Creative Mode ('gemini-2.5-flash-image') which requires image modality, not JSON
    if (model === 'gemini-2.5-flash-image') {
        const prompt = `Enhance this image to look more professional. Improve sharpness, reduce noise, and correct colors.`;

        try {
            const response = await ai.models.generateContent({
                model,
                contents: {
                    parts: [
                        { text: prompt },
                        {
                            inlineData: {
                                mimeType: imageState.file.type,
                                data: base64Image,
                            },
                        },
                    ],
                },
                config: {
                    responseModalities: [Modality.IMAGE],
                },
            });

            let enhancedImageBase64: string | undefined;
            for (const part of response.candidates[0].content.parts) {
                if (part.inlineData) {
                    enhancedImageBase64 = part.inlineData.data;
                    break;
                }
            }

            if (!enhancedImageBase64) {
                throw new Error("Không nhận được ảnh đã nâng cấp từ mô hình.");
            }

            // Since this model doesn't provide a JSON analysis, we construct a placeholder result.
            return {
                overall_quality: 'excellent',
                sharpness_change: '+',
                noise_reduction: true,
                recommended_action: ['Áp dụng nâng cấp AI.'],
                confidence_score: 0.95,
                enhanced_image: enhancedImageBase64,
            };
        } catch (error) {
            console.error("Lỗi khi gọi Gemini API (Creative Mode):", error);
            throw error;
        }
    }

    // Handle Standard Mode which supports JSON output
    const jsonSchema = {
        type: Type.OBJECT,
        properties: {
            overall_quality: {
                type: Type.STRING,
                description: 'Đánh giá chất lượng tổng thể của ảnh. Các giá trị có thể là: "excellent", "good", "fair", "poor".',
                enum: ['excellent', 'good', 'fair', 'poor'],
            },
            sharpness_change: {
                type: Type.STRING,
                description: 'Cho biết độ nét đã được tăng (+), giảm (-), hay giữ nguyên (=).',
                enum: ['+', '=', '-'],
            },
            noise_reduction: {
                type: Type.BOOLEAN,
                description: 'Cho biết liệu có áp dụng giảm nhiễu hay không.',
            },
            recommended_action: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Một mảng các hành động được đề xuất để cải thiện ảnh.',
            },
            confidence_score: {
                type: Type.NUMBER,
                description: 'Điểm tin cậy của phân tích, từ 0.0 đến 1.0.',
            },
            enhanced_image: {
                type: Type.STRING,
                description: 'Ảnh đã được cải thiện dưới dạng chuỗi base64.',
            },
        },
        required: ["overall_quality", "sharpness_change", "noise_reduction", "recommended_action", "confidence_score", "enhanced_image"],
    };

    const imageMetadata = {
        width_px: imageState.width,
        height_px: imageState.height,
        dpi: imageState.dpi,
    };

    const prompt = `Phân tích và nâng cấp hình ảnh được cung cấp. Cung cấp cả ảnh đã nâng cấp và phân tích chi tiết.
    Metadata của ảnh: ${JSON.stringify(imageMetadata)}.
    Chỉ trả về một đối tượng JSON hợp lệ, không có định dạng markdown hay bất kỳ văn bản nào khác. JSON phải tuân thủ nghiêm ngặt schema đã cho.`;

    try {
        const response = await ai.models.generateContent({
            model,
            contents: {
                parts: [
                    { text: prompt },
                    {
                        inlineData: {
                            mimeType: imageState.file.type,
                            data: base64Image,
                        },
                    },
                ],
            },
            config: {
                responseMimeType: 'application/json',
                responseSchema: jsonSchema,
            }
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString);
        return result as AnalysisResult;

    } catch (error) {
        console.error("Lỗi khi gọi Gemini API:", error);
        
        // Preserve existing retry logic for server-side errors
        let retryCount = 0;
        const maxRetries = 3;
        let delay = 3000;

        const attemptRetry = async (): Promise<AnalysisResult> => {
            if (retryCount >= maxRetries) {
                throw new Error("Đã thử lại nhiều lần nhưng vẫn thất bại. Vui lòng thử lại sau.");
            }
            
            retryCount++;
            await new Promise(res => setTimeout(res, delay));
            delay *= 2; // Exponential backoff

            console.log(`Đang thử lại lần ${retryCount}...`);
            
            try {
                const response = await ai.models.generateContent({
                    model,
                    contents: { parts: [{ text: prompt }, { inlineData: { mimeType: imageState.file.type, data: base64Image } }] },
                    config: { responseMimeType: 'application/json', responseSchema: jsonSchema }
                });
                const jsonString = response.text.trim();
                return JSON.parse(jsonString) as AnalysisResult;
            } catch (retryError) {
                console.error(`Lỗi khi thử lại lần ${retryCount}:`, retryError);
                return attemptRetry();
            }
        };

        if (error instanceof Error && (error.message.includes('500') || error.message.includes('503'))) {
            return attemptRetry();
        }

        throw error;
    }
}
